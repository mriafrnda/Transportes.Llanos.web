# Llanos Hermanos SRL – Consulta de rutas y registro de reservas

Proyecto integrador web de **Programación Web (UAIN1349P)** – Evaluación Final.
Aplicación con front-end responsivo (HTML, CSS, JavaScript y Bootstrap) y back-end en **Node.js + Express** con API RESTful.
Usa **únicamente datos ficticios**. Sin base de datos, pagos, autenticación ni servicios en la nube.

## Requisitos

- [Node.js](https://nodejs.org/) 18 o superior (probado con Node 22).

## Instalación y ejecución

```bash
cd backend
npm install
node server.js
```

Abrir en el navegador: <http://localhost:3000>

(Opcional) Cambiar el puerto: `PORT=4000 node server.js` (en Windows PowerShell: `$env:PORT=4000; node server.js`).

## Pruebas automáticas de la API

```bash
cd backend
npm test
```

Ejecuta 11 casos de prueba (CP01–CP11) con el ejecutor integrado de Node (`node:test`).

## Estructura

```
proyecto-integrador/
├── docs/                      Documentos PDF [1.1], [1.2], [1.3]
├── frontend/
│   ├── index.html             HTML semántico, formulario y secciones
│   ├── css/styles.css         Flexbox/Grid, media queries, personalización de Bootstrap
│   ├── js/app.js              Eventos, DOM, validación y consumo de la API (fetch)
│   ├── img/                   Logo y fotografía de la empresa
│   └── vendor/                Bootstrap 5.3.3 (archivos locales, sin CDN)
├── backend/
│   ├── server.js              Express: archivos estáticos, JSON, errores 400/404
│   ├── routes/api.js          Rutas de la API RESTful
│   ├── data/rutas.json        Catálogo de rutas (JSON local)
│   ├── tests/api.test.js      Pruebas automáticas
│   └── package.json
├── [1.6]_reflexion_curricular.pdf
└── README.md
```

## API RESTful

Las reservas se guardan **solo en memoria** (se borran al reiniciar el servidor).

### `GET /api/rutas`
Lista las rutas. Filtro opcional: `?origen=Cajamarca`.

```json
{
  "total": 4,
  "rutas": [
    { "id": 1, "origen": "Cajamarca", "destino": "Combayo", "salida": "06:00", "precio": 10 }
  ]
}
```

### `GET /api/rutas/:id`
Devuelve una ruta. `404` si no existe: `{ "error": "La ruta solicitada no existe." }`

### `POST /api/reservas`
Registra una solicitud de reserva. Encabezado `Content-Type: application/json`.

Petición:
```json
{ "nombre": "Juan Demo", "rutaId": 1, "fecha": "2026-10-05", "pasajeros": 2, "consentimiento": true }
```

Respuesta `201`:
```json
{
  "mensaje": "Solicitud registrada. Guarde su código para consultar el estado.",
  "reserva": {
    "codigo": "LH-7K3M9P",
    "estado": "Pendiente de confirmación",
    "nombre": "Juan Demo",
    "ruta": "Cajamarca → Combayo",
    "salida": "06:00",
    "fecha": "2026-10-05",
    "pasajeros": 2,
    "total": 20
  }
}
```

Respuesta `400` (datos inválidos):
```json
{
  "error": "Datos inválidos.",
  "errores": [ { "campo": "pasajeros", "mensaje": "El número de pasajeros debe ser un entero entre 1 y 5." } ]
}
```

Reglas: alias de 3 a 40 caracteres (letras, números, espacio, `.`, `'`, `-`); ruta existente; fecha válida desde hoy hasta 60 días;
pasajeros entero de 1 a 5; `consentimiento` debe ser `true`. Un JSON mal formado también devuelve `400`.

### `GET /api/reservas/:codigo`
Consulta el estado con el código `LH-XXXXXX`. Devuelve `200` con datos mínimos y el titular enmascarado:

```json
{ "codigo": "LH-7K3M9P", "estado": "Pendiente de confirmación", "titular": "Ju***",
  "ruta": "Cajamarca → Combayo", "salida": "06:00", "fecha": "2026-10-05", "pasajeros": 2, "total": 20 }
```

`400` si el formato del código es inválido; `404` si no existe. Cualquier otra ruta bajo `/api` responde `404`.

### Ejemplo con curl

```bash
curl http://localhost:3000/api/rutas
curl -X POST http://localhost:3000/api/reservas -H "Content-Type: application/json" \
  -d '{"nombre":"Juan Demo","rutaId":1,"fecha":"2026-10-05","pasajeros":2,"consentimiento":true}'
```

## Privacidad por diseño (Ley N.° 29733)

- Solo 4 campos (alias ficticio, ruta, fecha, pasajeros); sin DNI, teléfono ni correo.
- Consentimiento obligatorio validado en el navegador y en el servidor.
- El titular se muestra enmascarado (`Ju***`) en la consulta.
- Reservas solo en memoria; el servidor no registra el contenido de las peticiones.
- Sin cookies, sin analítica y sin recursos de terceros (política CSP restrictiva).

Detalle completo en `docs/[1.3]_privacidad_y_etica.pdf`.
