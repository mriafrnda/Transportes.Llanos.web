// frontend/js/app.js
// Lógica del front-end: carga de rutas (GET), registro de reservas (POST),
// consulta de estado (GET), validación con retroalimentación y accesibilidad.

'use strict';

const PATRON_NOMBRE = /^[\p{L}\p{N} .'-]+$/u;
const PATRON_CODIGO = /^LH-[A-HJ-NP-Z2-9]{6}$/;

let rutas = []; // arreglo de objetos con las rutas recibidas de la API

// ---------- referencias al DOM ----------
const formReserva = document.getElementById('formReserva');
const inputNombre = document.getElementById('nombre');
const selectRuta = document.getElementById('ruta');
const inputFecha = document.getElementById('fecha');
const inputPasajeros = document.getElementById('pasajeros');
const checkConsent = document.getElementById('consentimiento');
const resumenPrecio = document.getElementById('resumenPrecio');
const mensajeReserva = document.getElementById('mensajeReserva');
const contadorNombre = document.getElementById('contadorNombre');
const btnReservar = document.getElementById('btnReservar');

const formConsulta = document.getElementById('formConsulta');
const inputCodigo = document.getElementById('codigo');
const resultadoConsulta = document.getElementById('resultadoConsulta');

const listaRutas = document.getElementById('listaRutas');

// ---------- utilidades ----------
function formatoSoles(valor) {
  return 'S/ ' + Number(valor).toFixed(2);
}

function fechaLocalISO(fecha) {
  const a = fecha.getFullYear();
  const m = String(fecha.getMonth() + 1).padStart(2, '0');
  const d = String(fecha.getDate()).padStart(2, '0');
  return `${a}-${m}-${d}`;
}

function crear(etiqueta, clases, texto) {
  const el = document.createElement(etiqueta);
  if (clases) el.className = clases;
  if (texto !== undefined) el.textContent = texto; // textContent evita inyección de HTML
  return el;
}

// ---------- validación por campo (devuelve un mensaje o '' si es válido) ----------
const validadores = {
  nombre() {
    const v = inputNombre.value.trim();
    if (v.length < 3) return 'Escribe un alias de al menos 3 caracteres.';
    if (v.length > 40) return 'El alias no puede superar los 40 caracteres.';
    if (!PATRON_NOMBRE.test(v)) return 'Usa solo letras, números, espacios, punto, apóstrofo o guion.';
    return '';
  },
  ruta() {
    return selectRuta.value === '' ? 'Selecciona una ruta.' : '';
  },
  fecha() {
    if (inputFecha.value === '') return 'Selecciona la fecha de viaje.';
    const hoy = new Date();
    const limite = new Date();
    limite.setDate(limite.getDate() + 60);
    if (inputFecha.value < fechaLocalISO(hoy)) return 'La fecha no puede ser anterior a hoy.';
    if (inputFecha.value > fechaLocalISO(limite)) return 'Solo se reserva con hasta 60 días de anticipación.';
    return '';
  },
  pasajeros() {
    const n = Number(inputPasajeros.value);
    if (inputPasajeros.value === '' || !Number.isInteger(n) || n < 1 || n > 5) {
      return 'Ingresa un número entero de pasajeros entre 1 y 5.';
    }
    return '';
  },
  consentimiento() {
    return checkConsent.checked ? '' : 'Debes aceptar el aviso de privacidad para continuar.';
  }
};

const camposReserva = {
  nombre: inputNombre,
  ruta: selectRuta,
  fecha: inputFecha,
  pasajeros: inputPasajeros,
  consentimiento: checkConsent
};

function mostrarError(input, mensaje) {
  const caja = document.getElementById(input.id + 'Error');
  if (caja) caja.textContent = mensaje;
  input.classList.toggle('is-invalid', mensaje !== '');
  input.setAttribute('aria-invalid', mensaje !== '' ? 'true' : 'false');
  if (mensaje === '') input.classList.remove('is-invalid');
}

function validarCampo(clave) {
  const mensaje = validadores[clave]();
  mostrarError(camposReserva[clave], mensaje);
  return mensaje === '';
}

function validarFormularioReserva() {
  let primerInvalido = null;
  Object.keys(camposReserva).forEach((clave) => {
    const ok = validarCampo(clave);
    if (!ok && !primerInvalido) primerInvalido = camposReserva[clave];
  });
  if (primerInvalido) primerInvalido.focus(); // el foco va al primer error (accesibilidad)
  return primerInvalido === null;
}

// ---------- mensajes de estado ----------
function mostrarAlerta(contenedor, tipo, texto) {
  contenedor.replaceChildren(crear('div', `alert alert-${tipo} mb-0`, texto));
}

// ---------- RUTAS: GET /api/rutas ----------
async function cargarRutas() {
  try {
    const resp = await fetch('/api/rutas');
    if (!resp.ok) throw new Error('Respuesta no válida: ' + resp.status);
    const datos = await resp.json();
    rutas = datos.rutas;
    mostrarRutas();
    llenarSelectRutas();
  } catch (err) {
    listaRutas.replaceChildren(
      crear('p', 'alert alert-danger', 'No se pudieron cargar las rutas. Verifica que el servidor esté en ejecución.')
    );
  } finally {
    listaRutas.setAttribute('aria-busy', 'false');
  }
}

function mostrarRutas() {
  listaRutas.replaceChildren();
  rutas.forEach((ruta) => {
    const col = crear('div', 'col-sm-6 col-lg-3');
    const tarjeta = crear('article', 'tarjeta-ruta');
    tarjeta.appendChild(crear('h3', '', `${ruta.origen} → ${ruta.destino}`));
    tarjeta.appendChild(crear('p', '', `Salida: ${ruta.salida}`));
    tarjeta.appendChild(crear('p', 'precio', formatoSoles(ruta.precio)));

    const boton = crear('button', 'btn btn-outline-primary btn-sm', 'Reservar esta ruta');
    boton.type = 'button';
    boton.setAttribute('aria-label', `Reservar la ruta ${ruta.origen} a ${ruta.destino}`);
    boton.addEventListener('click', () => elegirRuta(ruta.id)); // evento click
    tarjeta.appendChild(boton);

    col.appendChild(tarjeta);
    listaRutas.appendChild(col);
  });
}

function llenarSelectRutas() {
  rutas.forEach((ruta) => {
    const opcion = document.createElement('option');
    opcion.value = String(ruta.id);
    opcion.textContent = `${ruta.origen} → ${ruta.destino} (${ruta.salida})`;
    selectRuta.appendChild(opcion);
  });
}

function elegirRuta(id) {
  selectRuta.value = String(id);
  actualizarResumen();
  validarCampo('ruta');
  document.getElementById('reserva').scrollIntoView();
  inputNombre.focus();
}

// ---------- resumen de precio (manipulación del DOM) ----------
function actualizarResumen() {
  const ruta = rutas.find((r) => String(r.id) === selectRuta.value);
  const n = Number(inputPasajeros.value);
  if (!ruta) {
    resumenPrecio.textContent = 'Seleccione una ruta para ver el total.';
    return;
  }
  if (!Number.isInteger(n) || n < 1 || n > 5) {
    resumenPrecio.textContent = `Tarifa por pasajero: ${formatoSoles(ruta.precio)}.`;
    return;
  }
  resumenPrecio.textContent =
    `${n} pasajero(s) × ${formatoSoles(ruta.precio)} = Total: ${formatoSoles(ruta.precio * n)}`;
}

// ---------- RESERVA: POST /api/reservas ----------
function mostrarTicket(contenedor, reserva, titular) {
  const ticket = crear('div', 'ticket');
  ticket.appendChild(crear('p', 'mb-1 fw-bold', 'Estado: ' + reserva.estado));
  ticket.appendChild(crear('p', 'codigo mb-0', reserva.codigo));

  const lista = crear('dl');
  const filas = [
    ['Titular', titular],
    ['Ruta', reserva.ruta],
    ['Salida', reserva.salida],
    ['Fecha', reserva.fecha],
    ['Pasajeros', String(reserva.pasajeros)],
    ['Total', formatoSoles(reserva.total)]
  ];
  filas.forEach(([clave, valor]) => {
    lista.appendChild(crear('dt', '', clave));
    lista.appendChild(crear('dd', '', valor));
  });
  ticket.appendChild(lista);
  contenedor.replaceChildren(ticket);
}

async function enviarReserva(evento) {
  evento.preventDefault();
  mensajeReserva.replaceChildren();

  if (!validarFormularioReserva()) {
    mostrarAlerta(mensajeReserva, 'danger', 'Revisa los campos marcados en rojo.');
    return;
  }

  const cuerpo = {
    nombre: inputNombre.value.trim(),
    rutaId: Number(selectRuta.value),
    fecha: inputFecha.value,
    pasajeros: Number(inputPasajeros.value),
    consentimiento: checkConsent.checked
  };

  btnReservar.disabled = true;
  btnReservar.textContent = 'Enviando…';
  try {
    const resp = await fetch('/api/reservas', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(cuerpo)
    });
    const datos = await resp.json();

    if (resp.status === 400 && Array.isArray(datos.errores)) {
      // errores de validación del servidor: se muestran junto a cada campo
      const mapa = { rutaId: 'ruta' };
      datos.errores.forEach((e) => {
        const clave = mapa[e.campo] || e.campo;
        if (camposReserva[clave]) mostrarError(camposReserva[clave], e.mensaje);
      });
      mostrarAlerta(mensajeReserva, 'danger', 'El servidor encontró datos inválidos. Revisa el formulario.');
      return;
    }
    if (!resp.ok) throw new Error(datos.error || 'Error inesperado');

    mostrarTicket(mensajeReserva, datos.reserva, cuerpo.nombre);
    formReserva.reset();
    contadorNombre.textContent = '0';
    actualizarResumen();
    establecerFechaMinima();
    Object.values(camposReserva).forEach((c) => mostrarError(c, ''));
  } catch (err) {
    mostrarAlerta(mensajeReserva, 'danger', 'No se pudo registrar la reserva. Inténtalo nuevamente.');
  } finally {
    btnReservar.disabled = false;
    btnReservar.textContent = 'Registrar reserva';
  }
}

// ---------- CONSULTA: GET /api/reservas/:codigo ----------
async function consultarReserva(evento) {
  evento.preventDefault();
  resultadoConsulta.replaceChildren();
  const codigo = inputCodigo.value.trim().toUpperCase();

  if (!PATRON_CODIGO.test(codigo)) {
    mostrarError(inputCodigo, 'Ingresa un código válido con el formato LH-XXXXXX.');
    inputCodigo.focus();
    return;
  }
  mostrarError(inputCodigo, '');

  try {
    const resp = await fetch('/api/reservas/' + encodeURIComponent(codigo));
    const datos = await resp.json();
    if (resp.status === 404) {
      mostrarAlerta(resultadoConsulta, 'warning', 'No encontramos una reserva con ese código.');
      return;
    }
    if (!resp.ok) throw new Error(datos.error || 'Error inesperado');
    mostrarTicket(resultadoConsulta, datos, datos.titular);
  } catch (err) {
    mostrarAlerta(resultadoConsulta, 'danger', 'No se pudo consultar la reserva. Inténtalo nuevamente.');
  }
}

// ---------- configuración inicial ----------
function establecerFechaMinima() {
  const hoy = new Date();
  const limite = new Date();
  limite.setDate(limite.getDate() + 60);
  inputFecha.min = fechaLocalISO(hoy);
  inputFecha.max = fechaLocalISO(limite);
}

// ---------- eventos ----------
document.addEventListener('DOMContentLoaded', () => { // evento 1
  document.getElementById('anio').textContent = new Date().getFullYear();
  establecerFechaMinima();
  cargarRutas();
});

inputNombre.addEventListener('input', () => { // evento 2: contador en vivo y limpieza de "<" y ">"
  inputNombre.value = inputNombre.value.replace(/[<>]/g, '');
  contadorNombre.textContent = String(inputNombre.value.length);
  if (inputNombre.classList.contains('is-invalid')) validarCampo('nombre');
});

selectRuta.addEventListener('change', () => { // evento 3
  actualizarResumen();
  validarCampo('ruta');
});

inputPasajeros.addEventListener('input', actualizarResumen); // evento 4

Object.keys(camposReserva).forEach((clave) => { // evento 5: validación al salir de cada campo
  camposReserva[clave].addEventListener('blur', () => validarCampo(clave));
});
checkConsent.addEventListener('change', () => validarCampo('consentimiento'));
inputFecha.addEventListener('change', () => validarCampo('fecha'));

formReserva.addEventListener('submit', enviarReserva); // evento 6
formConsulta.addEventListener('submit', consultarReserva); // evento 7
inputCodigo.addEventListener('input', () => {
  inputCodigo.value = inputCodigo.value.toUpperCase();
});
