// backend/routes/api.js
// API RESTful de Llanos Hermanos (datos ficticios, almacenados en memoria).
const express = require('express');
const crypto = require('crypto');
const rutas = require('../data/rutas.json'); // JSON local (solo lectura)

const router = express.Router();

// Las reservas viven SOLO en memoria: se pierden al reiniciar el servidor
// (minimización de datos y plazo de conservación mínimo).
const reservas = new Map(); // clave: código de reserva -> objeto reserva
const MAX_RESERVAS = 1000;
const ALFABETO = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // sin 0/O/1/I para evitar confusiones
const PATRON_CODIGO = /^LH-[A-HJ-NP-Z2-9]{6}$/;
const PATRON_NOMBRE = /^[\p{L}\p{N} .'-]+$/u; // letras, números, espacio, punto, apóstrofo y guion

// ---------- utilidades ----------
function hoyLima() {
  // Fecha de hoy (YYYY-MM-DD) en zona horaria de Perú
  return new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Lima' }).format(new Date());
}

function sumarDias(fechaISO, dias) {
  const d = new Date(fechaISO + 'T00:00:00Z');
  d.setUTCDate(d.getUTCDate() + dias);
  return d.toISOString().slice(0, 10);
}

function fechaValida(fecha) {
  if (typeof fecha !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(fecha)) return false;
  const d = new Date(fecha + 'T00:00:00Z');
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === fecha;
}

function generarCodigo() {
  let codigo;
  do {
    let sufijo = '';
    for (let i = 0; i < 6; i++) sufijo += ALFABETO[crypto.randomInt(ALFABETO.length)];
    codigo = 'LH-' + sufijo;
  } while (reservas.has(codigo));
  return codigo;
}

function enmascarar(nombre) {
  // Muestra solo las 2 primeras letras: "Juan Demo" -> "Ju***"
  return nombre.slice(0, 2) + '***';
}

function validarReserva(body) {
  const errores = [];
  const { nombre, rutaId, fecha, pasajeros, consentimiento } = body || {};

  const nombreLimpio = typeof nombre === 'string' ? nombre.trim() : '';
  if (nombreLimpio.length < 3 || nombreLimpio.length > 40) {
    errores.push({ campo: 'nombre', mensaje: 'El alias debe tener entre 3 y 40 caracteres.' });
  } else if (!PATRON_NOMBRE.test(nombreLimpio)) {
    errores.push({ campo: 'nombre', mensaje: 'Solo se permiten letras, números, espacios, punto, apóstrofo y guion.' });
  }

  const ruta = rutas.find((r) => r.id === Number(rutaId));
  if (!ruta) {
    errores.push({ campo: 'rutaId', mensaje: 'Seleccione una ruta válida.' });
  }

  if (!fechaValida(fecha)) {
    errores.push({ campo: 'fecha', mensaje: 'Ingrese una fecha válida (AAAA-MM-DD).' });
  } else {
    const hoy = hoyLima();
    if (fecha < hoy) {
      errores.push({ campo: 'fecha', mensaje: 'La fecha de viaje no puede ser anterior a hoy.' });
    } else if (fecha > sumarDias(hoy, 60)) {
      errores.push({ campo: 'fecha', mensaje: 'Solo se aceptan reservas hasta con 60 días de anticipación.' });
    }
  }

  const n = Number(pasajeros);
  if (!Number.isInteger(n) || n < 1 || n > 5) {
    errores.push({ campo: 'pasajeros', mensaje: 'El número de pasajeros debe ser un entero entre 1 y 5.' });
  }

  if (consentimiento !== true) {
    errores.push({ campo: 'consentimiento', mensaje: 'Debe aceptar el aviso de privacidad y confirmar que usa datos ficticios.' });
  }

  return { errores, datos: { nombre: nombreLimpio, ruta, fecha, pasajeros: n } };
}

// ---------- rutas ----------

// GET /api/rutas            -> lista todas las rutas (filtro opcional ?origen=Cajamarca)
router.get('/rutas', (req, res) => {
  let lista = rutas;
  if (typeof req.query.origen === 'string' && req.query.origen.trim() !== '') {
    const o = req.query.origen.trim().toLowerCase();
    lista = rutas.filter((r) => r.origen.toLowerCase() === o);
  }
  res.json({ total: lista.length, rutas: lista });
});

// GET /api/rutas/:id        -> una ruta (404 si no existe)
router.get('/rutas/:id', (req, res) => {
  const ruta = rutas.find((r) => String(r.id) === req.params.id);
  if (!ruta) return res.status(404).json({ error: 'La ruta solicitada no existe.' });
  res.json(ruta);
});

// POST /api/reservas        -> registra una solicitud de reserva (400 si hay errores)
router.post('/reservas', (req, res) => {
  const { errores, datos } = validarReserva(req.body);
  if (errores.length > 0) {
    return res.status(400).json({ error: 'Datos inválidos.', errores });
  }
  if (reservas.size >= MAX_RESERVAS) {
    return res.status(503).json({ error: 'Se alcanzó el límite de reservas de la demostración.' });
  }

  const codigo = generarCodigo();
  const reserva = {
    codigo,
    estado: 'Pendiente de confirmación',
    nombre: datos.nombre,
    ruta: `${datos.ruta.origen} → ${datos.ruta.destino}`,
    salida: datos.ruta.salida,
    fecha: datos.fecha,
    pasajeros: datos.pasajeros,
    total: datos.ruta.precio * datos.pasajeros
  };
  reservas.set(codigo, reserva);

  res.status(201).json({
    mensaje: 'Solicitud registrada. Guarde su código para consultar el estado.',
    reserva
  });
});

// GET /api/reservas/:codigo -> consulta el estado (datos mínimos, nombre enmascarado)
router.get('/reservas/:codigo', (req, res) => {
  const codigo = req.params.codigo.toUpperCase();
  if (!PATRON_CODIGO.test(codigo)) {
    return res.status(400).json({ error: 'El código debe tener el formato LH-XXXXXX.' });
  }
  const r = reservas.get(codigo);
  if (!r) return res.status(404).json({ error: 'No se encontró una reserva con ese código.' });

  res.json({
    codigo: r.codigo,
    estado: r.estado,
    titular: enmascarar(r.nombre),
    ruta: r.ruta,
    salida: r.salida,
    fecha: r.fecha,
    pasajeros: r.pasajeros,
    total: r.total
  });
});

module.exports = router;
