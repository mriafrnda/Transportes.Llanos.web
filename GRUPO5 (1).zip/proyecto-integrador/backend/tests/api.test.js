// backend/tests/api.test.js  ->  ejecutar con: npm test
process.env.NODE_ENV = 'test';
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const app = require('../server');

let servidor;
let base;
let codigoCreado;

function fechaEn(dias) {
  const d = new Date();
  d.setDate(d.getDate() + dias);
  return new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Lima' }).format(d);
}

const reservaValida = () => ({
  nombre: 'Juan Demo',
  rutaId: 1,
  fecha: fechaEn(3),
  pasajeros: 2,
  consentimiento: true
});

async function post(body, cruda = false) {
  return fetch(base + '/api/reservas', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: cruda ? body : JSON.stringify(body)
  });
}

before(async () => {
  await new Promise((ok) => { servidor = app.listen(0, ok); });
  base = `http://127.0.0.1:${servidor.address().port}`;
});
after(() => servidor.close());

test('CP01 GET /api/rutas devuelve 200 y 4 rutas', async () => {
  const r = await fetch(base + '/api/rutas');
  const j = await r.json();
  assert.equal(r.status, 200);
  assert.equal(j.total, 4);
  assert.equal(j.rutas.length, 4);
});

test('CP02 GET /api/rutas/99 devuelve 404', async () => {
  const r = await fetch(base + '/api/rutas/99');
  assert.equal(r.status, 404);
  assert.ok((await r.json()).error);
});

test('CP03 POST /api/reservas válido devuelve 201, código y total correcto', async () => {
  const r = await post(reservaValida());
  const j = await r.json();
  assert.equal(r.status, 201);
  assert.match(j.reserva.codigo, /^LH-[A-HJ-NP-Z2-9]{6}$/);
  assert.equal(j.reserva.total, 20); // 2 pasajeros x S/ 10.00
  assert.equal(j.reserva.estado, 'Pendiente de confirmación');
  codigoCreado = j.reserva.codigo;
});

test('CP04 POST sin consentimiento devuelve 400', async () => {
  const r = await post({ ...reservaValida(), consentimiento: false });
  const j = await r.json();
  assert.equal(r.status, 400);
  assert.ok(j.errores.some((e) => e.campo === 'consentimiento'));
});

test('CP05 POST con 6 pasajeros devuelve 400', async () => {
  const r = await post({ ...reservaValida(), pasajeros: 6 });
  assert.equal(r.status, 400);
  assert.ok((await r.json()).errores.some((e) => e.campo === 'pasajeros'));
});

test('CP06 POST con caracteres peligrosos en el alias devuelve 400', async () => {
  const r = await post({ ...reservaValida(), nombre: '<script>alert(1)</script>' });
  assert.equal(r.status, 400);
  assert.ok((await r.json()).errores.some((e) => e.campo === 'nombre'));
});

test('CP07 GET /api/reservas/:codigo devuelve 200 con titular enmascarado', async () => {
  const r = await fetch(`${base}/api/reservas/${codigoCreado}`);
  const j = await r.json();
  assert.equal(r.status, 200);
  assert.equal(j.titular, 'Ju***');
  assert.equal(j.nombre, undefined); // el nombre completo nunca se devuelve
});

test('CP08 GET con código inexistente devuelve 404 y con formato inválido 400', async () => {
  const a = await fetch(`${base}/api/reservas/LH-ABCDEF`);
  const b = await fetch(`${base}/api/reservas/xyz`);
  assert.equal(a.status, 404);
  assert.equal(b.status, 400);
});

test('CP09 POST con JSON mal formado devuelve 400', async () => {
  const r = await post('{"nombre": ', true);
  assert.equal(r.status, 400);
});

test('CP10 POST con fecha pasada devuelve 400', async () => {
  const r = await post({ ...reservaValida(), fecha: fechaEn(-1) });
  assert.equal(r.status, 400);
  assert.ok((await r.json()).errores.some((e) => e.campo === 'fecha'));
});

test('CP11 El servidor sirve el front-end estático y responde 404 a rutas de API inexistentes', async () => {
  const home = await fetch(base + '/');
  const css = await fetch(base + '/css/styles.css');
  const nada = await fetch(base + '/api/no-existe');
  assert.equal(home.status, 200);
  assert.match(home.headers.get('content-type'), /text\/html/);
  assert.equal(css.status, 200);
  assert.equal(nada.status, 404);
});
