// backend/server.js
// Servidor Express: sirve el front-end estático y expone la API REST bajo /api
const express = require('express');
const path = require('path');
const api = require('./routes/api');

const app = express();
const PORT = process.env.PORT || 3000;
const FRONTEND_DIR = path.join(__dirname, '..', 'frontend');

app.disable('x-powered-by');

// Cabeceras básicas de seguridad (privacidad por diseño)
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader(
    'Content-Security-Policy',
    "default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; frame-ancestors 'none'"
  );
  next();
});

// Registro mínimo: método, ruta y estado. NUNCA se registra el cuerpo de las peticiones.
app.use((req, res, next) => {
  res.on('finish', () => {
    if (process.env.NODE_ENV !== 'test') {
      console.log(`${req.method} ${req.path} -> ${res.statusCode}`);
    }
  });
  next();
});

app.use(express.json({ limit: '10kb' }));

// API RESTful
app.use('/api', api);
app.use('/api', (req, res) => {
  res.status(404).json({ error: 'Ruta de la API no encontrada.' });
});

// Front-end estático
app.use(express.static(FRONTEND_DIR));
app.use((req, res) => {
  res.status(404).type('text').send('Página no encontrada.');
});

// Manejo de errores (JSON mal formado -> 400)
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  if (err.type === 'entity.parse.failed') {
    return res.status(400).json({ error: 'El cuerpo de la petición no es un JSON válido.' });
  }
  if (err.type === 'entity.too.large') {
    return res.status(413).json({ error: 'El cuerpo de la petición es demasiado grande.' });
  }
  console.error('Error interno:', err.message);
  res.status(500).json({ error: 'Error interno del servidor.' });
});

if (require.main === module) {
  app.listen(PORT, () => {
    console.log(`Llanos Hermanos disponible en http://localhost:${PORT}`);
  });
}

module.exports = app;
